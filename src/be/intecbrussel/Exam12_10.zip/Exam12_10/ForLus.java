package be.intecbrussel.Exam12_10;

public class ForLus {
    public static void main(String[] args) {
        for (int i=2; i<=98;i +=2){
            System.out.println(i);
            }

    }
}
