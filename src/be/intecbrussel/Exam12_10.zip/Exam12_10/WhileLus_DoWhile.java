package be.intecbrussel.Exam12_10;

public class WhileLus_DoWhile {
    public static void main(String[] args) {
        int i =1;
        while(i<=99){
            System.out.println(i);
            i +=2;
        }

        }

    }

